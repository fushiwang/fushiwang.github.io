Social Vulnerability, Disaster Exposure, and County Economic Recovery
Fushi Wang, Zishuo Xu, Zachary Walton, Kashish Gupta, and Elric Ford

This archive contains the 14 R scripts supplied with the newest paper, the project license, and previously distributed cleaned inputs for the three modeling scripts. The storm extract includes all 60,234 county-coded events in the analysis years 2000–2005 and every column selected by the models. The other inputs contain county unemployment measures and CDC's 2000 Social Vulnerability Index.

Extract the archive and open the R project. From the project folder, run a modeling script with Rscript, for example:
  Rscript scripts/modeling/modeling_vulnerability_magnitude.R

The event-magnitude and event-type scripts run independently. The original modeling_unemployment.R is included as research source. Running it from a fresh R session stops at the first regression because the standardized magnitude column is entirely missing. Its later recovery section also references objects from an earlier session. The authors’ saved unemployment and recovery tables are in reported-tables/. Output tables use tables/. The scripts in scripts/cleaning/ and scripts/exploration/ document preparation and additional analyses. These require additional raw or intermediate files (NOAA Storm Events, CDC SVI, county economic statistics, and Census County Business Patterns). They reference the original project directory structure. Full project repository cited in the paper:
  https://github.com/BU-MA415-Spring2026/final-group-project-group-7

R packages loaded by the project scripts:
  dplyr, fixest, gridExtra, haven, here, modelsummary, readr, scales, stargazer, tibble, tidyr, tidyverse, tinytable

The separate disaster-data.zip download contains the eight data frames exported from the supplied modeling workspace, including merged and lagged analysis panels. The retained cleaned inputs and saved result tables in this code archive are from the earlier project package.
