library(tidyverse)
library(here)
library(scales)
library(gridExtra)

# load cleaned storm data
raw <- read_csv(here("data", "cleaned", "disaster", "storms_cleaned.csv"), show_col_types = FALSE)

# helper: z-score damage/injury/death columns, sum positive z-scores into composite severity index
add_severity <- function(df) {
  df %>%
    mutate(
      across(
        c(damage_properties, damage_crops, total_injuries, total_deaths),
        ~ (.x - mean(.x, na.rm = TRUE)) / sd(.x, na.rm = TRUE),
        .names = "z_{.col}"
      )
    ) %>%
    mutate(
      severity =
        pmax(z_damage_properties, 0) +
        pmax(z_damage_crops, 0) +
        pmax(z_total_injuries, 0) +
        pmax(z_total_deaths, 0)
    )
}

###################################################################
# plot 1: distribution of severity across all episodes

# episode-level summary across all years
data <- raw %>%
  group_by(EPISODE_ID) %>%
  summarize(
    damage_properties = sum(damage_properties, na.rm = TRUE),
    damage_crops = sum(damage_crops, na.rm = TRUE),
    total_injuries = sum(total_injuries, na.rm = TRUE),
    total_deaths = sum(total_deaths, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  add_severity()

# flag severe episodes and compute summary stats for annotation
plot_data <- data %>%
  filter(severity > 5)

summary_stats <- plot_data %>%
  summarize(
    avg_damage = mean(damage_properties + damage_crops, na.rm = TRUE),
    avg_injuries = mean(total_injuries, na.rm = TRUE),
    avg_deaths = mean(total_deaths, na.rm = TRUE)
  )

stats_label <- paste0(
  "Average statistics\n",
  "Damage:   $", comma(round(summary_stats$avg_damage, 0)), "\n",
  "Injuries: ", number(summary_stats$avg_injuries, accuracy = 0.01), "\n",
  "Deaths:   ", number(summary_stats$avg_deaths, accuracy = 0.01)
)

p <- ggplot(plot_data, aes(x = severity)) +
  geom_histogram(
    bins = 100,
    fill = "steelblue",
    color = "white",
    linewidth = 0.25
  ) +
  annotate(
    "label",
    x = 150,
    y = 30,
    label = stats_label,
    hjust = 0,
    vjust = 1,
    family = "mono",
    size = 3.8,
    label.size = 0.25,
    fill = alpha("white", 0.92)
  ) +
  labs(
    title = "Distribution of Notable Disaster Events",
    subtitle = "Event-level severity index for episodes with severity greater than 5",
    x = "Severity index",
    y = "Number of events",
    caption = "Severity index is the sum of strictly positive values for property damage, crop damage, injuries, and deaths."
  ) +
  scale_x_continuous(
    expand = expansion(mult = c(0.02, 0.04))
  ) +
  scale_y_continuous(
    expand = expansion(mult = c(0, 0.08))
  ) +
  theme_minimal(base_size = 13, base_family = "serif") +
  theme(
    plot.title = element_text(face = "bold", size = 16, margin = margin(b = 4)),
    plot.subtitle = element_text(size = 11, margin = margin(b = 10)),
    axis.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.3),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    plot.caption = element_text(size = 9, color = "grey35", hjust = 0.4, face = "italic"),
    plot.margin = margin(15, 18, 15, 15)
  )

print(p)

ggsave(plot = p,
       width = 8,
       height = 7,
       filename = here("figures", "disaster", "severity_d1.pdf"))

###########################################################
# plot 2: all vs severe event types, restricted to 2000-2005

# episode-level summary with year and event type
data <- raw %>%
  group_by(EPISODE_ID) %>%
  summarize(
    year = max(year),
    event = max(EVENT_TYPE),
    damage_properties = sum(damage_properties, na.rm = TRUE),
    damage_crops = sum(damage_crops, na.rm = TRUE),
    total_injuries = sum(total_injuries, na.rm = TRUE),
    total_deaths = sum(total_deaths, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  add_severity() %>%
  filter(year <= 2005)

# shared theme for horizontal bar charts
plot_theme <- theme_minimal(base_size = 13, base_family = "serif") +
  theme(
    plot.title = element_text(face = "bold", size = 14, margin = margin(b = 4)),
    plot.subtitle = element_text(size = 11, margin = margin(b = 8)),
    axis.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.3),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    plot.margin = margin(12, 12, 12, 12)
  )

# count all episodes and severe-only episodes by event type
g1_data <- data %>%
  count(event, name = "n", sort = TRUE)

g2_data <- data %>%
  filter(severity > 5) %>%
  count(event, name = "n", sort = TRUE)

g1 <- g1_data %>%
  slice_head(n = 21) %>%
  ggplot(aes(x = reorder(event, n), y = n/100)) +
  geom_col(fill = "seagreen", width = 0.75) +
  coord_flip() +
  scale_y_continuous(
    labels = comma,
    expand = expansion(mult = c(0, 0.05))
  ) +
  labs(
    title = "All Disaster Events",
    subtitle = "Count of observations by event type",
    x = NULL,
    y = "Number of observations \n(in hundreds)"
  ) +
  plot_theme

g2 <- g2_data %>%
  ggplot(aes(x = reorder(event, n), y = n)) +
  geom_col(fill = "tomato", width = 0.75) +
  coord_flip() +
  scale_y_continuous(
    labels = comma,
    expand = expansion(mult = c(0, 0.05))
  ) +
  labs(
    title = "Severe Disaster Events",
    subtitle = "Count of observations by event type, severity > 5",
    x = NULL,
    y = "Number of observations \n(in absolute)"
  ) +
  plot_theme

g <- grid.arrange(g1, g2, ncol = 2)

ggsave(plot = g, filename = here("figures", "disasters_d2.pdf"))

#############################################
# plot 3: annual sum and mean severity, 2000-2005

# episode-level annual summary (no event type needed)
data <- raw %>%
  group_by(EPISODE_ID) %>%
  summarize(
    year = max(year),
    damage_properties = sum(damage_properties, na.rm = TRUE),
    damage_crops = sum(damage_crops, na.rm = TRUE),
    total_injuries = sum(total_injuries, na.rm = TRUE),
    total_deaths = sum(total_deaths, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  add_severity() %>%
  filter(year <= 2005)

yearly_index <- data %>%
  group_by(year) %>%
  summarize(
    sum_index = sum(severity, na.rm = TRUE),
    mean_index = mean(severity, na.rm = TRUE),
    .groups = "drop"
  )

# rescale mean severity to share axis with sum
scale_factor <- max(yearly_index$sum_index, na.rm = TRUE) /
  max(yearly_index$mean_index, na.rm = TRUE)

yearly_index_plot <- yearly_index %>%
  transmute(
    year,
    `Sum of severity` = sum_index,
    `Mean severity` = mean_index * scale_factor
  ) %>%
  pivot_longer(
    cols = c(`Sum of severity`, `Mean severity`),
    names_to = "stat",
    values_to = "value"
  )

h <- ggplot(yearly_index_plot, aes(x = factor(year), y = value, fill = stat)) +
  geom_col(position = position_dodge(width = 0.8), width = 0.7) +
  scale_y_continuous(
    labels = comma,
    name = "Sum of severity",
    sec.axis = sec_axis(~ . / scale_factor, name = "Mean severity")
  ) +
  labs(
    title = "Annual Sum and Mean of Disaster Severity",
    subtitle = "Mean severity is rescaled for visual comparison",
    x = "Year",
    fill = NULL
  ) +
  theme_minimal(base_size = 13, base_family = "serif") +
  theme(
    plot.title = element_text(face = "bold", size = 16, margin = margin(b = 4)),
    plot.subtitle = element_text(size = 11, margin = margin(b = 10)),
    axis.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.3),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    legend.position = "top",
    plot.margin = margin(15, 18, 15, 15)
  )

ggsave(plot = h, filename = here("figures", "years_d3.pdf"))

#############################################
# plot 4: event type breakdown for regressable sample (has magnitude, non-missing damage)

data <- raw %>%
  group_by(EPISODE_ID) %>%
  summarize(
    year = max(year),
    event = max(EVENT_TYPE),
    damage_properties = sum(damage_properties, na.rm = TRUE),
    damage_crops = sum(damage_crops, na.rm = TRUE),
    total_injuries = sum(total_injuries, na.rm = TRUE),
    total_deaths = sum(total_deaths, na.rm = TRUE),
    magnitude = mean(MAGNITUDE),
    .groups = "drop"
  ) %>%
  add_severity() %>%
  filter(year <= 2005, !is.na(magnitude), !is.na(damage_properties))

plot_theme <- theme_minimal(base_size = 13, base_family = "serif") +
  theme(
    plot.title = element_text(face = "bold", size = 14, margin = margin(b = 4)),
    plot.subtitle = element_text(size = 11, margin = margin(b = 8)),
    axis.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    panel.grid.major.y = element_blank(),
    panel.grid.major.x = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.3),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    plot.margin = margin(12, 12, 12, 12)
  )

g1_data <- data %>%
  count(event, name = "n", sort = TRUE)

g2_data <- data %>%
  filter(severity > 5) %>%
  count(event, name = "n", sort = TRUE)

q1 <- g1_data %>%
  slice_head(n = 21) %>%
  ggplot(aes(x = reorder(event, n), y = n/100)) +
  geom_col(fill = "seagreen", width = 0.75) +
  coord_flip() +
  scale_y_continuous(
    labels = comma,
    expand = expansion(mult = c(0, 0.05))
  ) +
  labs(
    title = "Regressable Disaster Events",
    subtitle = "Count of observations by event type",
    x = NULL,
    y = "Number of observations \n(in hundreds)"
  ) +
  plot_theme

g <- grid.arrange(g1, g2, q1, ncol = 3)

ggsave(plot = g,
       width = 15,
       height = 9,
       filename = here("figures", "disaster", "disasters_d2.pdf"))
