library(tidyverse)
library(here)
library(scales)

# load cleaned gdp data
raw <- read_csv(here("data","cleaned","county", "county_gdp.csv"))

gdp <- raw %>%
  select(State, County, Year, Value)

# restrict to selected louisiana counties for case study
gdp <- gdp %>%
  filter(
    State == "LA",
    County %in% c(
      "Avoyelles",
      "Bienville",
      "Caddo",
      "Catahoula",
      "Claiborne",
      "East Baton Rouge",
      "Lafourche",
      "Madison",
      "Tensas",
      "Webster"
    )
  )

# compute year-over-year pct change in county gdp
gdp <- gdp %>%
  arrange(County, Year) %>%
  group_by(County) %>%
  mutate(
    Value = as.numeric(Value),
    pct_change = 100 * (Value - lag(Value)) / lag(Value)
  ) %>%
  ungroup()

# plot gdp growth over time for selected counties
p <- gdp %>%
  mutate(Value = as.numeric(Value)) %>%
  ggplot(aes(x = Year, y = pct_change, group = County, color = County)) +
  geom_line(linewidth = 0.9) +
  geom_point(size = 1.8) +
  labs(
    title = "County GDP Over Time in Louisiana",
    subtitle = "Selected Louisiana counties",
    x = "Year",
    y = "Change in GDP",
    color = "County"
  ) +
  scale_y_continuous(labels = comma) +
  theme_minimal(base_size = 13, base_family = "serif") +
  theme(
    plot.title = element_text(face = "bold", size = 16, margin = margin(b = 4)),
    plot.subtitle = element_text(size = 11, margin = margin(b = 10)),
    axis.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.3),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    plot.margin = margin(15, 18, 15, 15),
    legend.position = "right"
  )

print(p)
