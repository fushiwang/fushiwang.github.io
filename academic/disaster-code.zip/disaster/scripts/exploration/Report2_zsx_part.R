library(tidyverse)
library(here)

# load cleaned vulnerability panel
SVI <- read_csv(here("data", "cleaned", "vulnerability", "panel_clean.csv"))

# plot 1: distribution of overall vulnerability score
print(
  ggplot(SVI, aes(x = SPL_THEMES)) +
    geom_histogram(bins = 40) +
    labs(
      title = "Distribution of Overall Vulnerability",
      x = "Raw Vulnerability Score (SPL_THEMES)",
      y = "Count"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      axis.title = element_text(size = 12)
    )
)

# plot 2: mean vulnerability by year
print(
  SVI %>%
    group_by(year) %>%
    summarise(mean_vul = mean(SPL_THEMES, na.rm = TRUE)) %>%
    ggplot(aes(x = year, y = mean_vul)) +
    geom_line(linewidth = 1) +
    geom_point(size = 2) +
    labs(
      title = "Average Vulnerability Over Time",
      x = "Year",
      y = "Mean Vulnerability (SPL_THEMES)"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      axis.title = element_text(size = 12)
    )
)

# plot 3: unemployment rate vs overall vulnerability
print(
  ggplot(SVI, aes(x = EP_UNEMP, y = RPL_THEMES)) +
    geom_point(alpha = 0.15, size = 0.8) +
    geom_smooth(method = "loess", se = FALSE, linewidth = 1) +
    labs(
      title = "Unemployment vs Overall Vulnerability",
      x = "Unemployment Rate (%)",
      y = "Overall Vulnerability (RPL_THEMES)"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      axis.title = element_text(size = 12)
    )
)

# plot 4: minority population share vs overall vulnerability
print(
  ggplot(SVI, aes(x = EP_MINRTY, y = RPL_THEMES)) +
    geom_point(alpha = 0.15, size = 0.8) +
    geom_smooth(method = "loess", se = FALSE, linewidth = 1) +
    labs(
      title = "Minority Population Share vs Overall Vulnerability",
      x = "Minority Population (%)",
      y = "Overall Vulnerability (RPL_THEMES)"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      axis.title = element_text(size = 12)
    )
)

# plot 5: housing indicators vs overall vulnerability
housing_plot_data <- SVI %>%
  select(RPL_THEMES, EP_MUNIT, EP_MOBILE, EP_CROWD, EP_GROUPQ) %>%
  pivot_longer(
    cols = c(EP_MUNIT, EP_MOBILE, EP_CROWD, EP_GROUPQ),
    names_to = "variable",
    values_to = "value"
  ) %>%
  mutate(
    variable = recode(
      variable,
      EP_MUNIT = "Multi-unit Housing",
      EP_MOBILE = "Mobile Homes",
      EP_CROWD = "Crowded Housing",
      EP_GROUPQ = "Group Quarters"
    )
  )

print(
  ggplot(housing_plot_data, aes(x = value, y = RPL_THEMES)) +
    geom_point(alpha = 0.12, size = 0.7) +
    geom_smooth(method = "loess", se = FALSE, linewidth = 1) +
    facet_wrap(~ variable, scales = "free_x", ncol = 2) +
    labs(
      title = "Housing-Related Indicators vs Overall Vulnerability",
      x = "Percentage (%)",
      y = "Overall Vulnerability (RPL_THEMES)"
    ) +
    theme_minimal() +
    theme(
      plot.title = element_text(size = 14, face = "bold"),
      axis.title = element_text(size = 12),
      strip.title = element_text(size = 11, face = "bold")
    )
)
