library(here)
library(tidyverse)
library(scales)

# load cleaned gdp, unemployment, and storm data
gdp <- read_csv(here("data","cleaned","county","county_gdp.csv"))
uemp <- read_csv(here("data","cleaned","county","county_unemployment.csv"))
storms <- read_csv(here("data","cleaned","disaster","storms_cleaned.csv"))

# derive louisiana counties with cumulative damage above $1M for case study filter
counties <- storms %>%
  filter(CZ_TYPE == "C") %>%
  filter(STATE == "LOUISIANA") %>%
  filter(damage_crops + damage_properties > 1000000) %>%
  group_by(CZ_NAME) %>%
  summarize(dmg = sum(damage_properties + damage_crops)) %>%
  mutate(county = str_to_lower(CZ_NAME)) %>%
  pull(county)

# plot 1: gdp growth in high-damage louisiana counties
p <- gdp %>%
  filter(State == "LA") %>%
  mutate(
    county = str_to_lower(County),
    Year = as.numeric(Year),
    Value = as.numeric(Value)
  ) %>%
  filter(county %in% counties) %>%
  arrange(county, Year) %>%
  group_by(county) %>%
  mutate(
    gdp_pct_change = 100 * (Value - lag(Value)) / lag(Value)
  ) %>%
  ungroup() %>%
  filter(Year != 2001, !is.na(gdp_pct_change)) %>%
  ggplot(aes(x = Year, y = gdp_pct_change, group = county)) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey50",
    linewidth = 0.4
  ) +
  geom_vline(
    xintercept = 2005,
    linetype = "dashed",
    color = "tomato",
    linewidth = 0.5
  ) +
  geom_line(
    color = "steelblue",
    alpha = 0.45,
    linewidth = 0.9
  ) +
  geom_point(
    color = "steelblue",
    alpha = 0.6,
    size = 1.7
  ) +
  labs(
    title = "GDP Growth in High-Damage Louisiana Counties",
    subtitle = "Year-over-year county GDP percent change, 2002–2010",
    x = "Year",
    y = "GDP growth (%)",
    caption = "Dashed vertical line marks 2005, the year of Hurricanes Katrina and Rita. Growth is calculated as the percent change in county GDP from the previous year."
  ) +
  scale_x_continuous(
    breaks = 2002:2010,
    expand = expansion(mult = c(0.02, 0.03))
  ) +
  scale_y_continuous(
    labels = label_number(accuracy = 0.1),
    expand = expansion(mult = c(0.05, 0.08))
  ) +
  theme_minimal(base_size = 13, base_family = "serif") +
  theme(
    plot.title = element_text(face = "bold", size = 16, margin = margin(b = 4)),
    plot.subtitle = element_text(size = 11, margin = margin(b = 10)),
    axis.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "grey85", linewidth = 0.35),
    panel.grid.major.y = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.3),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    plot.caption = element_text(size = 9, color = "grey35", hjust = 0.4, face = "italic"),
    plot.margin = margin(15, 18, 15, 15)
  )

print(p)

ggsave(
  plot = p,
  filename = here("figures", "county","gdp_c1.pdf")
)

# plot 2: unemployment in high-damage louisiana parishes
# strip parish suffix to match county names used in the counties vector
p1 <- uemp %>%
  filter(State == "LA") %>%
  mutate(
    county = str_to_lower(str_remove(Area_Name, " Parish, LA$")),
    Year = as.numeric(Year),
    Unemployment_rate = as.numeric(Unemployment_rate)
  ) %>%
  filter(county %in% counties) %>%
  ggplot(aes(x = Year, y = Unemployment_rate, group = county)) +
  geom_hline(
    yintercept = 0,
    linetype = "dashed",
    color = "grey50",
    linewidth = 0.4
  ) +
  geom_vline(
    xintercept = 2005,
    linetype = "dashed",
    color = "tomato",
    linewidth = 0.5
  ) +
  geom_line(
    color = "darkgoldenrod1",
    alpha = 0.45,
    linewidth = 0.9
  ) +
  geom_point(
    color = "darkgoldenrod1",
    alpha = 0.6,
    size = 1.7
  ) +
  labs(
    title = "Unemployment Rates in High-Damage Louisiana Parishes",
    subtitle = "Annual parish unemployment rates, 2000–2010",
    x = "Year",
    y = "Unemployment rate (%)",
    caption = "Dashed vertical line marks 2005, the year of Hurricanes Katrina and Rita."
  ) +
  scale_x_continuous(
    breaks = 2000:2010,
    expand = expansion(mult = c(0.02, 0.03))
  ) +
  scale_y_continuous(
    labels = label_number(accuracy = 0.1),
    expand = expansion(mult = c(0.05, 0.08))
  ) +
  theme_minimal(base_size = 13, base_family = "serif") +
  theme(
    plot.title = element_text(face = "bold", size = 16, margin = margin(b = 4)),
    plot.subtitle = element_text(size = 11, margin = margin(b = 10)),
    axis.title = element_text(face = "bold"),
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_line(color = "grey85", linewidth = 0.35),
    panel.grid.major.y = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.3),
    axis.ticks = element_line(color = "black", linewidth = 0.3),
    plot.caption = element_text(size = 9, color = "grey35", hjust = 0.4, face = "italic"),
    plot.margin = margin(15, 18, 15, 15)
  )

print(p1)

ggsave(
  plot = p1,
  filename = here("figures","county","unemployment_c2.pdf")
)
