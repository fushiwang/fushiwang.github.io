library(here)
library(fixest)
library(modelsummary)
library(scales)
library(tidyverse)
library(stargazer)

# load unemployment, vulnerability, and storm data
uemp <- read_csv(here("data","cleaned","county","unemployment_cleaned.csv"))
svi2000 <- read_csv(here("data","cleaned","vulnerability","vulnerability_cleaned_2000.csv"))
storms <- read_csv(here("data","cleaned","disaster","storms_cleaned.csv"))

# filter to county zones, build 5-digit fips, restrict to 2000-2005, drop rows missing magnitude
storms <- storms %>%
  filter(CZ_TYPE == "C") %>%
  select(STATE_FIPS, CZ_FIPS, STATE, CZ_NAME, YEAR, EVENT_TYPE, EPISODE_ID, MAGNITUDE,TOR_F_SCALE,damage_properties,damage_crops, total_injuries, total_deaths) %>%
  filter(YEAR %in% 2000:2005) %>%
  mutate(FIPS = STATE_FIPS*1000 + CZ_FIPS) %>%
  filter(!is.na(MAGNITUDE)) %>%
  mutate(FIPS = as.character(FIPS)) %>%
  mutate(FIPS = stringr::str_pad(FIPS, width = 5, side = "left", pad = "0")) %>%
  select(-STATE_FIPS, -CZ_FIPS, -TOR_F_SCALE)

# keep only fips and vulnerability percentile (ustp) from svi
svi2000 <- svi2000 %>%
  select(STCOFIPS,STATE_NAME, COUNTY, USTP) %>%
  mutate(FIPS = as.character(STCOFIPS)) %>%
  select(FIPS, USTP)

# join storm events with county vulnerability
merged <- left_join(storms, svi2000, by = "FIPS")

# log-transform damage, standardize magnitude and vulnerability
reg_data <- merged %>%
  mutate(
    log_dmgp = log(damage_properties+1),
    log_dmgc = log(damage_crops+1),
    mag_z = as.numeric(scale(MAGNITUDE)),
    ustp_z = as.numeric(scale(USTP)),
  )

# expand panel to include county-years with no storm events (fill damage = 0)
storm_data <- reg_data %>%
  group_by(STATE, CZ_NAME, FIPS) %>%
  complete(
    YEAR = 2000:2005,
    fill = list(damage_properties = 0)
  ) %>%
  # forward/backward fill vulnerability for county-years missing svi observation
  fill(USTP, .direction = "downup") %>%
  ungroup() %>%
  mutate(YEAR = as.integer(YEAR))

# prep unemployment data with matching fips format and year type
unemp_data <- uemp %>%
  mutate(
    FIPS = str_pad(as.character(FIPS_Code), width = 5, pad = "0"),
    YEAR = as.integer(Year)
  )

# join on fips and year
merged_data <- storm_data %>%
  left_join(unemp_data, by = c("FIPS", "YEAR"))

# collapse to county-year: max magnitude, sum damage, standardize at county-year level
county_year <- merged_data %>%
  mutate(
    FIPS = str_pad(as.character(FIPS), width = 5, pad = "0"),
    YEAR = as.integer(YEAR)
  ) %>%
  group_by(FIPS, YEAR, STATE, CZ_NAME) %>%
  summarise(
    uempr   = first(Unemployment_rate),
    ustp_z  = first(ustp_z),
    mag     = max(MAGNITUDE, na.rm = TRUE),
    dmg     = sum(damage_properties, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  # max() returns -Inf for county-years with no storms; treat as 0
  mutate(mag = ifelse(is.infinite(mag), 0, mag)) %>%
  mutate(
    mag_z_cy = as.numeric(scale(mag)),
    log_dmg  = log1p(dmg),
    log_dmg_z = as.numeric(scale(log_dmg))
  )

# model 1: unemployment ~ magnitude x vulnerability, county + year fe
m1 <- feols(
  uempr ~ mag_z_cy * ustp_z | FIPS + YEAR,
  data = county_year,
  cluster = ~ FIPS
)

# model 2: unemployment ~ log damage x vulnerability, county + year fe
m2 <- feols(
  uempr ~ log_dmg_z * ustp_z | FIPS + YEAR,
  data = county_year,
  cluster = ~ FIPS
)

table_models <- list(
  "Magnitude x Vulnerability" = m1,
  "Damage x Vulnerability"    = m2
)

add_rows_tbl <- tribble(
  ~term,                 ~Magnitude, ~Damage,
  "County Fixed Effects", "Yes",      "Yes",
  "Year Fixed Effects",   "Yes",      "Yes",
  "SE Clustering",        "County",   "County"
)

# export table: unemployment ~ disaster severity x vulnerability
modelsummary(
  table_models,
  output = here("tables", "unemployment_vulnerability.tex"),
  title = "Disaster Severity, Vulnerability, and Unemployment",
  label = "tab:unemp_vulnerability",
  coef_map = c(
    "mag_z_cy"         = "Magnitude",
    "log_dmg_z"        = "Log Damage",
    "ustp_z"           = "Vulnerability",
    "mag_z_cy:ustp_z"  = "Magnitude $\\times$ Vulnerability",
    "log_dmg_z:ustp_z" = "Log Damage $\\times$ Vulnerability"
  ),
  statistic = "({std.error})",
  stars = c("*" = 0.1, "**" = 0.05, "***" = 0.01),
  fmt = 3,
  add_rows = add_rows_tbl,
  gof_map = tribble(
    ~raw,              ~clean,      ~fmt,
    "nobs",            "Num. Obs.", 0,
    "adj.r.squared",   "Adj. R$^2$", 3
  ),
  notes = paste0(
    "\\textit{Dependent variable: county-year unemployment rate. ",
    "All regressions include county and year fixed effects. ",
    "Standard errors are clustered by county. ",
    "The main coefficient of interest is the interaction between disaster severity and vulnerability.}"
  ),
  escape = FALSE
)

#################################
# lag model: unemployment response up to 4 years after extreme disaster shock

# slim unemployment and vulnerability data to fips, year, rate
uemp <- uemp %>% select(
  FIPS_Code, Year, Unemployment_rate
) %>% transmute(FIPS = FIPS_Code, Year = Year, uempr = Unemployment_rate)

svi2000 <- svi2000 %>%
  mutate(FIPS = as.numeric(FIPS))

uemp_vul <- left_join(uemp, svi2000, by = "FIPS")

# aggregate storms to fips-year: total magnitude and total damage
storms <- storms %>%
  mutate(FIPS = as.numeric(FIPS), Year = YEAR) %>%
  group_by(FIPS, Year) %>%
  summarize(
    mag = sum(MAGNITUDE),
    dmg = sum(damage_properties)
  )

# join unemployment + vulnerability with storm aggregates
merged <- left_join(uemp_vul, storms, by = c("FIPS","Year"))

# fill 0 for county-years with no storms
merged <- merged %>%
  mutate(
    mag = ifelse(is.na(mag), 0, mag),
    dmg = ifelse(is.na(dmg), 0, dmg)
  )

# clean types, forward/backward fill vulnerability, standardize
df <- merged %>%
  mutate(
    FIPS = as.integer(FIPS),
    Year = as.integer(Year),
    dmg  = coalesce(dmg, 0),
    mag  = coalesce(mag, 0)
  ) %>%
  arrange(FIPS, Year) %>%
  group_by(FIPS) %>%
  fill(USTP, .direction = "downup") %>%
  ungroup()

df <- df %>%
  mutate(
    ustp_z = as.numeric(scale(USTP))
  )

# flag county-years where total damage >= $1M, create up to 4-year lags
df <- df %>%
  mutate(
    big_disaster = as.integer(dmg >= 1000000)
  ) %>%
  arrange(FIPS, Year) %>%
  group_by(FIPS) %>%
  mutate(
    big_l1 = lag(big_disaster, 1, default = 0),
    big_l2 = lag(big_disaster, 2, default = 0),
    big_l3 = lag(big_disaster, 3, default = 0),
    big_l4 = lag(big_disaster, 4, default = 0)
  ) %>%
  ungroup()

# damage lag model: unempr ~ disaster shock and lags x vulnerability
m_lag90 <- feols(
  uempr ~
    big_disaster + big_l1 + big_l2 + big_l3 + big_l4 +
    big_disaster:ustp_z + big_l1:ustp_z + big_l2:ustp_z + big_l3:ustp_z +big_l4:ustp_z |
    Year,
  data = df,
  cluster = ~ FIPS
)

summary(m_lag90)

# --------------------------
# DAMAGE MODEL FOR TABLE
# --------------------------
# rename lags to generic shock_lX so both models share same formula
df_dmg <- df %>%
  mutate(
    shock_l1 = big_l1,
    shock_l2 = big_l2,
    shock_l3 = big_l3,
    shock_l4 = big_l4
  )

m_damage <- feols(
  uempr ~ shock_l1 + shock_l2 + shock_l3 + shock_l4 +
    shock_l1:ustp_z + shock_l2:ustp_z + shock_l3:ustp_z + shock_l4:ustp_z |
    Year,
  data = df_dmg,
  cluster = ~ FIPS
)

################################

# rebuild df from merged for magnitude model (reset lags)
df <- merged %>%
  mutate(
    FIPS = as.integer(FIPS),
    Year = as.integer(Year),
    dmg  = coalesce(dmg, 0),
    mag  = coalesce(mag, 0)
  ) %>%
  arrange(FIPS, Year) %>%
  group_by(FIPS) %>%
  fill(USTP, .direction = "downup") %>%
  ungroup() %>%
  mutate(
    ustp_z = as.numeric(scale(USTP))
  )

# 99th percentile threshold for extreme magnitude events (positive only)
p95 <- quantile(df$mag[df$mag > 0], 0.99, na.rm = TRUE)

# flag extreme magnitude events, create up to 4-year lags
df <- df %>%
  mutate(
    big_mag = as.integer(mag >= p95 & mag > 0)
  ) %>%
  arrange(FIPS, Year) %>%
  group_by(FIPS) %>%
  mutate(
    big_mag_l1 = lag(big_mag, 1, default = 0),
    big_mag_l2 = lag(big_mag, 2, default = 0),
    big_mag_l3 = lag(big_mag, 3, default = 0),
    big_mag_l4 = lag(big_mag, 4, default = 0)
  ) %>%
  ungroup()

# magnitude lag model: unempr ~ extreme magnitude shock and lags x vulnerability
m_lag_mag95 <- feols(
  uempr ~
    big_mag + big_mag_l1 + big_mag_l2 + big_mag_l3 + big_mag_l4 +
    big_mag:ustp_z + big_mag_l1:ustp_z + big_mag_l2:ustp_z +
    big_mag_l3:ustp_z + big_mag_l4:ustp_z |
    Year,
  data = df,
  cluster = ~ FIPS
)

summary(m_lag_mag95)

# --------------------------
# MAGNITUDE MODEL FOR TABLE
# --------------------------
df_mag <- df %>%
  mutate(
    shock_l1 = big_mag_l1,
    shock_l2 = big_mag_l2,
    shock_l3 = big_mag_l3,
    shock_l4 = big_mag_l4
  )

m_mag <- feols(
  uempr ~ shock_l1 + shock_l2 + shock_l3 + shock_l4 +
    shock_l1:ustp_z + shock_l2:ustp_z + shock_l3:ustp_z + shock_l4:ustp_z |
    Year,
  data = df_mag,
  cluster = ~ FIPS
)

models <- list(
  "Damage" = m_damage,
  "Magnitude" = m_mag
)

add_rows <- tribble(
  ~term, ~Damage, ~Magnitude,
  "Year Fixed Effects", "Yes", "Yes",
  "Standard Errors", "Clustered by county", "Clustered by county",
  "Shock Definition", "Damage 95th percentile", "Magnitude 99th percentile"
)

# export combined lag table
modelsummary(
  models,
  output = here("tables", "recovery_combined.tex"),
  title = "Vulnerability and Unemployment Recovery After Disaster Shocks",
  label = "tab:recovery_combined",
  coef_map = c(
    "shock_l1" = "Extreme Shock $(t-1)$",
    "shock_l2" = "Extreme Shock $(t-2)$",
    "shock_l3" = "Extreme Shock $(t-3)$",
    "shock_l4" = "Extreme Shock $(t-4)$",
    "shock_l1:ustp_z" = "Extreme Shock $(t-1) \\times$ Vulnerability",
    "shock_l2:ustp_z" = "Extreme Shock $(t-2) \\times$ Vulnerability",
    "shock_l3:ustp_z" = "Extreme Shock $(t-3) \\times$ Vulnerability",
    "shock_l4:ustp_z" = "Extreme Shock $(t-4) \\times$ Vulnerability"
  ),
  statistic = "({std.error})",
  stars = c("*" = .1, "**" = .05, "***" = .01),
  fmt = 3,
  add_rows = add_rows,
  gof_map = tribble(
    ~raw, ~clean, ~fmt,
    "nobs", "Num.Obs.", 0,
    "adj.r.squared", "Adj. R$^2$", 3
  ),
  notes = "Dependent variable: county unemployment rate. Only lagged effects are shown.",
  escape = FALSE
)
