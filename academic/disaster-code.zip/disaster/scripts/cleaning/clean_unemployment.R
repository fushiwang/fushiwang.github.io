library(tidyverse)
library(here)

raw <- read_csv(here("data","raw","county_census","education&employment","Unemployment2023.csv"))

data <- raw %>%
  filter(FIPS_Code > 0) %>%
  filter(str_detect(Attribute, "200[0-9]|2010")) %>%
  filter(str_detect(Area_Name, ",")) %>%
  extract(Attribute, into = c("variable", "Year"), regex = "(.+)_([0-9]{4})") %>%
  pivot_wider(names_from = variable, values_from = Value)

write_csv(data, here("data","cleaned","county","unemployment_cleaned.csv"))