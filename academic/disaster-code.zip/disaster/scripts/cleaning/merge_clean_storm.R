library(tidyverse)
library(haven)
library(here)
library(gridExtra)

# find all per-year storm csv files in raw disaster folder
path <- here("data", "raw", "disaster")
files <- list.files(path, pattern = "^storm\\d{4}\\.csv$")

# read each file into named list, then combine into single dataframe
storms <- list()

for (f in files) {
  name <- gsub("\\.csv$", "", f)
  storms[[name]] <- read_csv(file.path(path, f))
}

storms <- bind_rows(storms)

# parse property damage string (e.g. "1.5K") into numeric dollars
# combine direct and indirect injury and death counts
# parse crop damage string into numeric dollars
# keep only rows with at least one damage type recorded
storms <- storms %>%
  mutate(
    num = as.double(substr(DAMAGE_PROPERTY, 1, nchar(DAMAGE_PROPERTY) - 1)),
    suf = substr(DAMAGE_PROPERTY, nchar(DAMAGE_PROPERTY), nchar(DAMAGE_PROPERTY)),
    damage_properties = case_when(
      suf == "K" ~ num * 1e3,
      suf == "M" ~ num * 1e6,
      suf == "B" ~ num * 1e9,
    )
  ) %>%
  mutate(
    total_injuries = INJURIES_DIRECT + INJURIES_INDIRECT,
    total_deaths = DEATHS_DIRECT + DEATHS_INDIRECT
  ) %>%
  select(
    -starts_with("INJURIES"),
    -starts_with("DEATHS"),
    -DAMAGE_PROPERTY
  ) %>%
  mutate(
    num = as.double(substr(DAMAGE_CROPS, 1, nchar(DAMAGE_CROPS) - 1)),
    suf = substr(DAMAGE_CROPS, nchar(DAMAGE_CROPS), nchar(DAMAGE_CROPS)),
    damage_crops = case_when(
      suf == "K" ~ num * 1e3,
      suf == "M" ~ num * 1e6,
      suf == "B" ~ num * 1e9,
    )
  ) %>%
  filter(!is.na(damage_crops) | !is.na(damage_properties)) %>%
  select(
    -DAMAGE_CROPS,
    -num,
    -suf
  )

# storms within same month: exact day count
hold1 <- storms %>%
  filter(BEGIN_YEARMONTH == END_YEARMONTH) %>%
  mutate(
    duration = END_DAY - BEGIN_DAY + 1
  ) %>%
  select(-BEGIN_DAY, -END_DAY)

# storms spanning month boundary: assign median duration of 17 days
hold2 <- storms %>%
  filter(BEGIN_YEARMONTH != END_YEARMONTH) %>%
  mutate(
    duration = 17
  ) %>%
  select(-BEGIN_DAY, -END_DAY)

storms <- bind_rows(hold1, hold2)

# extract year and month from yearmonth integer (e.g. 200508 -> year=2005, month=08)
storms <- storms %>%
  mutate(
    year = substr(BEGIN_YEARMONTH, 1, 4),
    month = substr(BEGIN_YEARMONTH, 5, 6)
  ) %>%
  select(
    -BEGIN_YEARMONTH,
    -END_YEARMONTH
  )

# write cleaned storm data
write_csv(storms, here("data", "cleaned", "disaster", "storms_cleaned.csv"))
