library(tidyverse)
library(here)

# path to raw cbp county-level txt files (cbp00co.txt through cbp10co.txt)
path <- here("data", "raw", "county_census")

# load each year's cbp file and tag with year, then combine
df00 <- read_delim(file.path(path, "cbp00co.txt"), delim = ",") %>% mutate(year = 2000)
df01 <- read_delim(file.path(path, "cbp01co.txt"), delim = ",") %>% mutate(year = 2001)
df02 <- read_delim(file.path(path, "cbp02co.txt"), delim = ",") %>% mutate(year = 2002)
df03 <- read_delim(file.path(path, "cbp03co.txt"), delim = ",") %>% mutate(year = 2003)
df04 <- read_delim(file.path(path, "cbp04co.txt"), delim = ",") %>% mutate(year = 2004)
df05 <- read_delim(file.path(path, "cbp05co.txt"), delim = ",") %>% mutate(year = 2005)
df06 <- read_delim(file.path(path, "cbp06co.txt"), delim = ",") %>% mutate(year = 2006)
df07 <- read_delim(file.path(path, "cbp07co.txt"), delim = ",") %>% mutate(year = 2007)
df08 <- read_delim(file.path(path, "cbp08co.txt"), delim = ",") %>% mutate(year = 2008)
df09 <- read_delim(file.path(path, "cbp09co.txt"), delim = ",") %>% mutate(year = 2009)
df10 <- read_delim(file.path(path, "cbp10co.txt"), delim = ",") %>% mutate(year = 2010)

cbp_all <- bind_rows(
  df00, df01, df02, df03, df04,
  df05, df06, df07, df08, df09, df10
)

# remove per-year objects to free memory
rm(df00, df01, df02, df03, df04,
   df05, df06, df07, df08, df09, df10)

# build 5-digit fips from state and county codes, drop redundant columns
cbp_all <- cbp_all %>%
  mutate(
    fips = paste0(fipstate, fipscty)
  ) %>%
  select(
    year,
    fips,
    everything(),
    -fipstate,
    -fipscty,
    -emp_nf,
    -qp1_nf,
    -ap_nf
  )

# impute employment midpoint from empflag size class when exact count is suppressed
# cbp uses letter codes (A-M) representing employment size ranges
cbp_all <- cbp_all %>%
  mutate(
    emp = case_when(
      emp != 0 ~ emp,
      emp == 0 & empflag == "A" ~ 10,
      emp == 0 & empflag == "B" ~ 60,
      emp == 0 & empflag == "C" ~ 175,
      emp == 0 & empflag == "E" ~ 375,
      emp == 0 & empflag == "F" ~ 750,
      emp == 0 & empflag == "G" ~ 1750,
      emp == 0 & empflag == "H" ~ 3750,
      emp == 0 & empflag == "I" ~ 7500,
      emp == 0 & empflag == "J" ~ 17500,
      emp == 0 & empflag == "K" ~ 37500,
      emp == 0 & empflag == "L" ~ 75000,
      emp == 0 & empflag == "M" ~ 100000,
      TRUE ~ emp
    )
  )

# drop flag and census geography columns no longer needed
cbp_all <- cbp_all %>%
  select(-empflag, -censtate, -cencty)

# rename cryptic cbp column names to readable labels
cbp_all <- cbp_all %>%
  rename(
    industry_code = naics,
    employment = emp,
    first_quarter_payroll = qp1,
    annual_payroll = ap,
    establishments = est,
    establishments_1_4_employees = n1_4,
    establishments_5_9_employees = n5_9,
    establishments_10_19_employees = n10_19,
    establishments_20_49_employees = n20_49,
    establishments_50_99_employees = n50_99,
    establishments_100_249_employees = n100_249,
    establishments_250_499_employees = n250_499,
    establishments_500_999_employees = n500_999,
    establishments_1000_plus_employees = n1000,
    establishments_1000_1499_employees = n1000_1,
    establishments_1500_2499_employees = n1000_2,
    establishments_2500_4999_employees = n1000_3,
    establishments_5000_plus_employees = n1000_4
  )

# write cleaned cbp data
write_csv(cbp_all, here("data", "cleaned", "county", "cbp_all_clean.csv"))
