library(here)

parts_dir <- here("data", "cleaned", "CBP X County")
output_file <- here("data", "cleaned", "CBP X County", "cbp_all_clean.csv")

part_files <- list.files(
  parts_dir,
  pattern = "^cbp_all_clean_part[0-9]{3}\\.csv$",
  full.names = TRUE
)

part_files <- sort(part_files)

if (length(part_files) == 0) {
  stop("No CBP chunk files found.")
}

header <- readLines(part_files[1], n = 1, warn = FALSE)
part_body <- readLines(part_files[1], warn = FALSE)

writeLines(c(header, part_body[-1]), output_file, useBytes = TRUE)

if (length(part_files) > 1) {
  for (part_file in part_files[-1]) {
    lines <- readLines(part_file, warn = FALSE)
    cat(lines[-1], sep = "\n", file = output_file, append = TRUE)
    cat("\n", file = output_file, append = TRUE)
  }
}

message("Rebuilt file at: ", output_file)

