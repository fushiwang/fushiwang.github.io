Social Vulnerability, Disaster Exposure, and County Economic Recovery

These eight CSV files are exports of the county-level data frames in the authors' saved modeling workspace. Each filename is the original R object name. Original rows, variable names, and missing values (NA) are retained. Read FIPS as text to preserve leading zeros.

storms: county-year storm magnitude and damage, 2000–2005.
svi2000: baseline county social vulnerability.
uemp: county unemployment, 2000–2010.
uemp_vul: unemployment and baseline vulnerability.
merged: county unemployment, vulnerability and storm measures.
df, df_mag, df_dmg: analysis panels with derived shock measures and lags. See the accompanying modeling_unemployment.R script for variable definitions.

storms.csv: 8594 rows, 4 columns
svi2000.csv: 3141 rows, 2 columns
uemp.csv: 35364 rows, 3 columns
uemp_vul.csv: 35364 rows, 4 columns
merged.csv: 35364 rows, 6 columns
df.csv: 35364 rows, 17 columns
df_mag.csv: 35364 rows, 21 columns
df_dmg.csv: 35364 rows, 21 columns
