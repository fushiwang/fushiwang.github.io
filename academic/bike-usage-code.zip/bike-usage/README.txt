Predicting and Understanding Bike Usage Patterns

Fushi Wang’s R Markdown analysis of Washington, D.C., bike-sharing demand, with hourly and daily input files. Data source: Bike Sharing Dataset, Hadi Fanaee-T, UCI Machine Learning Repository (doi:10.24432/C5W894).

Open analysis.Rmd in RStudio and knit it to HTML, or run the following in R from this directory:

rmarkdown::render("analysis.Rmd", output_format = "html_document")

R packages: rmarkdown, knitr, car, nortest, lmtest, glmnet, ggplot2. HTML rendering also requires Pandoc. The web edition uses relative paths, fixes typographical errors and object references in the later notebook, uses alias(model) for a rank-deficient diagnostic, and sets a seed for cross-validation. The separately available PDF is the original project report.
