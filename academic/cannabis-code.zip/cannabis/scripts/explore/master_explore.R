
### RUN THIS BLOCK ###
library(here)

scripts <- c(
  "explore_alcohol_consumption.R",
  "explore_laws.R"
)

for (s in scripts) {
  cat("Running", s, "...\n")
  source(here("scripts", "explore", s))
}

cat("All exploring completed, and cleaned figures saved! yay no errors.\n")
### RUN THIS BLOCK ###