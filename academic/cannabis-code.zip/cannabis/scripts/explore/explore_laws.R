library(here)
library(tidyverse)
library(here)
library(tidyverse)

raw <- read_csv(here("data", "cleaned", "laws_cleaned.csv"))

blue_states <- c(
  "California", "Colorado", "Connecticut", "Delaware", "District of Columbia",
  "Hawaii", "Illinois", "Maine", "Maryland", "Massachusetts", "Michigan",
  "Minnesota", "Nevada", "New Hampshire", "New Jersey", "New Mexico",
  "New York", "Oregon", "Rhode Island", "Vermont", "Virginia", "Washington")

raw <- raw %>%
  mutate(party_group = if_else(State %in% blue_states, "Blue", "Red"))


##################################################################

party_plot <- ggplot(raw, aes(x = Year, y = PharmAppScaleZ, group = State, color = party_group)) +
  geom_line(alpha = 0.35, linewidth = 0.5) +
  theme_minimal() +
  labs(
    title = "Pharmaceutical Application Policy Score by State Over Time",
    subtitle = "States grouped into blue-leaning and red-leaning",
    x = "Year",
    y = "PharmAppScaleZ",
    color = "State group") +
  scale_color_manual(values = c("Blue" = "blue3", "Red" = "red3")) +
  scale_x_continuous(breaks = seq(min(raw$Year), max(raw$Year), by = 5))

##################################################################

application <- raw %>%
  transmute(
    State,
    Year,
    stat = "Application",
    Pharmaceutical = PharmAppScaleZ,
    Permissive = PermissiveAppScaleZ,
    Fiscal = FiscalAppScaleZ)

implementation <- raw %>%
  transmute(
    State,
    Year,
    stat = "Implementation",
    Pharmaceutical = PharmImpScaleZ,
    Permissive = PermissiveImpScaleZ,
    Fiscal = FiscalImpScaleZ)

temp <- bind_rows(application, implementation)

temp_long <- temp %>%
  pivot_longer(
    cols = c(Pharmaceutical, Permissive, Fiscal),
    names_to = "policy_type",
    values_to = "score")

summary_df <- temp_long %>%
  group_by(Year, stat, policy_type) %>%
  summarize(
    mean_score = mean(score, na.rm = TRUE),
    median_score = median(score, na.rm = TRUE),
    .groups = "drop")

ggplot(summary_df, aes(x = Year, y = mean_score,
                       color = policy_type, linetype = stat)) +
  geom_line(linewidth = 1.2) +
  theme_minimal() +
  labs(
    title = "Average Cannabis Policy Scores Over Time",
    x = "Year",
    y = "Mean score",
    color = "Policy type",
    linetype = NULL)

p <- ggplot(
  summary_df,
  aes(
    x = Year,
    y = mean_score,          
    color = policy_type,
    linetype = stat)) +
  geom_line(linewidth = 1.2) +
  scale_color_manual(
    values = c(
      "Pharmaceutical" = "tomato",
      "Permissive"     = "steelblue",
      "Fiscal"         = "darkgreen")) +
  scale_linetype_manual(
    values = c(
      "Application"    = "solid",
      "Implementation" = "22")) +
  scale_x_continuous(
    breaks = seq(min(summary_df$Year), max(summary_df$Year), by = 5),
    expand = expansion(mult = c(0.01, 0.02))) +
  labs(
    title = "Average Cannabis Policy Scores Over Time",
    subtitle = "Application and implementation scores by policy domain",
    x = "Year",
    y = "Average standardized score",
    color = "Policy domain",
    linetype = NULL) +
  theme_minimal(base_size = 14, base_family = "Times") +
  theme(
    plot.title = element_text(size = 17, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 12.5, face = "plain", hjust = 0.5, margin = margin(b = 12)),
    axis.title.x = element_text(size = 13, face = "bold", margin = margin(t = 10)),
    axis.title.y = element_text(size = 13, face = "bold", margin = margin(r = 10)),
    axis.text = element_text(size = 11, color = "black"),
    legend.title = element_text(size = 12, face = "bold"),
    legend.text = element_text(size = 11),
    legend.position = "bottom",
    legend.box = "vertical",
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.4),
    axis.ticks = element_line(color = "black", linewidth = 0.4),
    plot.margin = margin(15, 20, 15, 15))

ggsave(
  filename = here("figures", "policy_scores_over_time.pdf"),
  plot = p,
  width = 10,
  height = 6.5)


################################################################

library(gridExtra)
raw <- read_csv(here("data", "cleaned", "laws_cleaned.csv"))

blue_states <- c(
  "Arizona", "California", "Colorado", "Connecticut", "Delaware",
  "District of Columbia", "Georgia", "Hawaii", "Illinois", "Maine",
  "Maryland", "Massachusetts", "Michigan", "Minnesota", "Nevada",
  "New Hampshire", "New Jersey", "New Mexico", "New York", "Oregon",
  "Rhode Island", "Vermont", "Virginia", "Washington", "Wisconsin")

raw <- raw %>%
  mutate(
    party = if_else(State %in% blue_states, "Democratic", "Republican"))

plot_df <- bind_rows(
  raw %>%
    transmute(
      State, Year, party,
      stat = "Application",
      policy = "Pharmaceutical",
      score = PharmAppScaleZ),
  raw %>%
    transmute(
      State, Year, party,
      stat = "Implementation",
      policy = "Pharmaceutical",
      score = PharmImpScaleZ),
  raw %>%
    transmute(
      State, Year, party,
      stat = "Application",
      policy = "Permissive",
      score = PermissiveAppScaleZ),
  raw %>%
    transmute(
      State, Year, party,
      stat = "Implementation",
      policy = "Permissive",
      score = PermissiveImpScaleZ),
  raw %>%
    transmute(
      State, Year, party,
      stat = "Application",
      policy = "Fiscal",
      score = FiscalAppScaleZ),
  raw %>%
    transmute(
      State, Year, party,
      stat = "Implementation",
      policy = "Fiscal",
      score = FiscalImpScaleZ))

summary_df <- plot_df %>%
  group_by(Year, party, stat, policy) %>%
  summarize(
    mean_score = mean(score, na.rm = TRUE),
    median_score = median(score, na.rm = TRUE),
    .groups = "drop")

pub_theme <- theme_minimal(base_size = 14, base_family = "serif") +
  theme(
    plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 11.5, hjust = 0.5, margin = margin(b = 10)),
    axis.title.x = element_text(size = 12.5, face = "bold", margin = margin(t = 8)),
    axis.title.y = element_text(size = 12.5, face = "bold", margin = margin(r = 8)),
    axis.text = element_text(size = 10.5, color = "black"),
    legend.title = element_blank(),
    legend.text = element_text(size = 10.5),
    legend.position = "bottom",
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "grey85", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.4),
    axis.ticks = element_line(color = "black", linewidth = 0.4),
    plot.margin = margin(14, 18, 14, 14))

make_party_plot <- function(policy_name) {
  ggplot(
    summary_df %>% filter(policy == policy_name),
    aes(x = Year, y = mean_score, color = party, linetype = stat)) +
    geom_line(linewidth = 1.2) +
    scale_color_manual(values = c(
      "Democratic" = "#2C7FB8",
      "Republican" = "#CB181D")) +
    scale_linetype_manual(values = c(
      "Application" = "solid",
      "Implementation" = "22")) +
    scale_x_continuous(
      breaks = seq(min(summary_df$Year), max(summary_df$Year), by = 5),
      expand = expansion(mult = c(0.01, 0.02))) +
    labs(
      title = paste(policy_name, "Policy Scores"),
      subtitle = "State averages by partisan grouping",
      x = "Year",
      y = "Average standardized score") +
    pub_theme}

p_pharm <- make_party_plot("Pharmaceutical")
p_perm  <- make_party_plot("Permissive") + labs(y = "")
p_fisc  <- make_party_plot("Fiscal") + labs(y = "")

grouped <- grid.arrange(p_pharm, p_perm, p_fisc, ncol = 3)
ggsave(here("figures", "policy_by_party.png"), grouped, width = 15, height = 10)


     
