library(here)
library(tidyverse)
library(gridExtra)

alcohol <- read_csv(here("data","cleaned","alcohol_consumption_cleaned.csv"))
laws <- read_csv(here("data","cleaned","laws_cleaned.csv"))

plot_df <- alcohol %>%
  select(geographic_area, year, beer, wine, spirits, all_beverages) %>%
  pivot_longer(
    cols = c(beer, wine, spirits, all_beverages),
    names_to = "beverage",
    values_to = "consumption") %>%
  mutate(
    beverage = recode(
      beverage,
      beer = "Beer",
      wine = "Wine",
      spirits = "Spirits",
      all_beverages = "All beverages"))

summary_df <- plot_df %>%
  group_by(year, beverage) %>%
  summarize(
    mean_consumption = mean(consumption, na.rm = TRUE),
    median_consumption = median(consumption, na.rm = TRUE),
    .groups = "drop")

p <- ggplot(
  summary_df,
  aes(x = year, y = mean_consumption, color = beverage)) +
  geom_line(linewidth = 1.25) +
  scale_color_manual(
    values = c(
      "Beer" = "darkgoldenrod1",
      "Wine" = "deeppink1",
      "Spirits" = "darkorchid1",
      "All beverages" = "#222222")) +
  scale_x_continuous(
    breaks = seq(min(summary_df$year), max(summary_df$year), by = 5),
    expand = expansion(mult = c(0.01, 0.02))) +
  labs(
    title = "Average Per Capita Alcohol Consumption Over Time",
    subtitle = "Average across all geographic areas in the dataset",
    x = "Year",
    y = "Gallons of ethanol per capita",
    color = NULL) +
  theme_minimal(base_size = 14, base_family = "serif") +
  theme(
    plot.title = element_text(size = 19, face = "bold", hjust = 0.5),
    plot.subtitle = element_text(size = 12.5, hjust = 0.5, margin = margin(b = 12)),
    axis.title.x = element_text(size = 13, face = "bold", margin = margin(t = 10)),
    axis.title.y = element_text(size = 13, face = "bold", margin = margin(r = 10)),
    axis.text = element_text(size = 11, color = "black"),
    legend.text = element_text(size = 11),
    legend.position = "bottom",
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank(),
    panel.grid.major.y = element_line(color = "grey82", linewidth = 0.35),
    axis.line = element_line(color = "black", linewidth = 0.4),
    axis.ticks = element_line(color = "black", linewidth = 0.4),
    plot.margin = margin(15, 20, 15, 15))

ggsave(
  here("figures", "alcohol_over_time_by_beverage.png"),
  p,
  width = 11,
  height = 6.5)

#########################################################

alcohol <- read_csv(here("data", "cleaned", "alcohol_consumption_cleaned.csv"))
laws <- read_csv(here("data", "cleaned", "laws_cleaned.csv"))

merged <- laws %>%
  inner_join(
    alcohol %>%
      rename(State = geographic_area, Year = year) %>%
      select(State, Year, all_beverages),
    by = c("State", "Year"))

plot_df_std <- merged %>%
  group_by(Year) %>%
  summarize(
    mean_pharm_imp = mean(PharmImpScaleZ, na.rm = TRUE),
    mean_perm_imp  = mean(PermissiveImpScaleZ, na.rm = TRUE),
    mean_fisc_imp  = mean(FiscalImpScaleZ, na.rm = TRUE),
    mean_alcohol   = mean(all_beverages, na.rm = TRUE),
    .groups = "drop") %>%
  mutate(
    mean_pharm_imp = as.numeric(scale(mean_pharm_imp)),
    mean_perm_imp  = as.numeric(scale(mean_perm_imp)),
    mean_fisc_imp  = as.numeric(scale(mean_fisc_imp)),
    mean_alcohol   = as.numeric(scale(mean_alcohol))) %>%
  pivot_longer(
    cols = c(mean_pharm_imp, mean_perm_imp, mean_fisc_imp, mean_alcohol),
    names_to = "series",
    values_to = "value") %>%
  mutate(
    series = recode(
      series,
      mean_pharm_imp = "Pharmaceutical Implementation",
      mean_perm_imp  = "Permissive Implementation",
      mean_fisc_imp  = "Fiscal Implementation",
      mean_alcohol   = "All Beverages"))

g <- ggplot(plot_df_std, aes(x = Year, y = value, color = series, linetype = series)) +
  geom_line(linewidth = 1.2) +
  scale_color_manual(values = c(
    "Pharmaceutical Implementation" = "#d95f02",
    "Permissive Implementation"     = "#1f77b4",
    "Fiscal Implementation"         = "#2ca02c",
    "All Beverages"                 = "#222222")) +
  scale_linetype_manual(values = c(
    "Pharmaceutical Implementation" = "22",
    "Permissive Implementation"     = "22",
    "Fiscal Implementation"         = "22",
    "All Beverages"                 = "solid")) +
  labs(
    title = "Standardized Trends in Implementation Scores and Alcohol Consumption",
    x = "Year",
    y = "Standardized mean",
    color = NULL,
    linetype = NULL) +
  theme_minimal(base_size = 14, base_family = "serif") +
  theme(
    plot.title = element_text(face = "bold", hjust = 0.5),
    axis.title = element_text(face = "bold"),
    legend.position = "bottom",
    panel.grid.minor = element_blank(),
    panel.grid.major.x = element_blank())

ggsave(
  here("figures", "std_alcohol_law.png"),
  g,
  width = 11,
  height = 6.5)
