library(here)
library(tidyverse)
library(gridExtra)
library(fixest)
library(sandwich)
library(lmtest)
library(stargazer)
library(glmnet)
library(modelsummary)

alcohol <- read_csv(here("data", "cleaned", "alcohol_annual_sales_volume_1994_2023.csv"))
tax <- read_csv(here("data","cleaned","state_alcohol_rates_cleaned.csv"))
laws <- read_csv(here("data", "cleaned", "laws_cleaned.csv")) %>% mutate(
  PharmApp = round(PharmAppScaleZ * 12 / 100),
  PharmImp = round(PharmImpScaleZ * 12 / 100),
  PermissiveApp = round(PermissiveAppScaleZ * 12 / 100),
  PermissiveImp = round(PermissiveImpScaleZ * 12 / 100),
  FiscalApp = round(FiscalAppScaleZ * 12 / 100),
  FiscalImp = round(FiscalImpScaleZ * 12 / 100))

tax <- tax %>%
  select(
    State,
    Year,
    spirits_excise_tax_rate,
    beer_excise_tax_rate,
    wine_excise_tax_rate,
  ) %>%
  mutate(
    all_beverages_excise_tax_rate =
      (spirits_excise_tax_rate +
      beer_excise_tax_rate +
      wine_excise_tax_rate) / 3)

merged <- laws %>%
  inner_join(
    alcohol %>%
      rename(State = state, Year = year) %>%
      select(State, Year, sales_all_beverages_gallons_ethanol, sales_beer_gallons_ethanol,
             sales_spirits_gallons_ethanol,
             sales_wine_gallons_ethanol,
             population_21plus),
    by = c("State", "Year")) %>%
  mutate(all_beverages = sales_all_beverages_gallons_ethanol / population_21plus,
         wine = sales_wine_gallons_ethanol / population_21plus,
         beer = sales_beer_gallons_ethanol / population_21plus,
         spirits = sales_spirits_gallons_ethanol / population_21plus)

reg_data <- merged %>%
  mutate(
    PharmImpCount = round(PharmImpScaleZ * 12 / 100),
    PermissiveImpCount = round(PermissiveImpScaleZ * 12 / 100),
    FiscalImpCount = round(FiscalImpScaleZ * 12 / 100),
    scale_all_beverages = as.numeric(scale(all_beverages)),
    scale_beer = as.numeric(scale(beer)),
    scale_wine = as.numeric(scale(wine)),
    scale_spirits = as.numeric(scale(spirits))) %>%
  filter(
    !is.na(scale_all_beverages),
    !is.na(scale_beer),
    !is.na(scale_wine),
    !is.na(scale_spirits),
    !is.na(PharmImpCount),
    !is.na(PermissiveImpCount),
    !is.na(FiscalImpCount))

reg_data <- left_join(reg_data, tax,
                      by = c("State","Year"))

inc <- read_csv(here("data", "cleaned", "per_cap_inc_cleaned.csv"))
unemployment <- read_csv(here("data", "cleaned", "unemployment_cleaned.csv")) %>%
  pivot_longer(
    cols = -year,
    names_to = "State",
    values_to = "unemployment") %>%
  rename(Year = year) %>%
  mutate(
    Year = as.integer(Year),
    unemployment = as.numeric(unemployment))

reg_data <- left_join(reg_data, inc, by = c("State", "Year"))
reg_data <- left_join(reg_data, unemployment, by = c("State", "Year"))
reg_data <- reg_data %>%
  mutate(
    scale_per_capita_income_state = scale(per_capita_income))


summary_data_main <- reg_data %>%
  mutate(
    PharmImpCount = round(PharmImpScaleZ * 12 / 100),
    PermissiveImpCount = round(PermissiveImpScaleZ * 12 / 100),
    FiscalImpCount = round(FiscalImpScaleZ * 12 / 100)) %>%
  select(
    all_beverages,
    beer,
    wine,
    spirits,
    PharmImpCount,
    unemployment,
    per_capita_income,
    all_beverages_excise_tax_rate)

var_labels_main <- c(
  all_beverages = "All beverages",
  beer = "Beer",
  wine = "Wine",
  spirits = "Spirits",
  unemployment = "Unemployment Rates",
  per_capita_income = "Per-Capita Income",
  all_beverages_excise_tax_rate = "Average Alcohol Excise Tax Rate")

sumstats_main <- data.frame(
  Variable = var_labels_main[names(summary_data_main)],
  Mean = sapply(summary_data_main, function(x) mean(x, na.rm = TRUE)),
  SD = sapply(summary_data_main, function(x) sd(x, na.rm = TRUE)),
  Min = sapply(summary_data_main, function(x) min(x, na.rm = TRUE)),
  Max = sapply(summary_data_main, function(x) max(x, na.rm = TRUE)),
  row.names = NULL)

datasummary_df(
  sumstats_main,
  title = "Descriptive Statistics",
  fmt = 3,
  output = here("tables", "summary_statistics_main.tex"))


#############################################################

m_all <- lm(
  scale_all_beverages ~ PharmImpCount + PermissiveImpCount + FiscalImpCount,
  data = reg_data)

m_beer <- lm(
  scale_beer ~ PharmImpCount + PermissiveImpCount + FiscalImpCount,
  data = reg_data)

m_wine <- lm(
  scale_wine ~ PharmImpCount + PermissiveImpCount + FiscalImpCount,
  data = reg_data)

m_spirits <- lm(
  scale_spirits ~ PharmImpCount + PermissiveImpCount + FiscalImpCount,
  data = reg_data)

stargazer(
  m_all, m_beer, m_wine, m_spirits,
  type = "latex",
  out = here("tables","alcohols_t1.tex"),
  label = "tab:baseline",
  title = "Cannabis Policy Implementation and Alcohol Consumption: Baseline Associations",
  omit = c("Constant"),
  keep.stat = c("n", "rsq", "adj.rsq"),
  column.labels = c("All Beverages", "Beer", "Wine", "Spirits"),
  dep.var.labels = c("", "", "", ""),
  covariate.labels = c(
    "Pharmaceutical implementation count",
    "Permissive implementation count",
    "Fiscal implementation count"),
  digits = 3)


################################################################################

reg_all <- reg_data %>%
  mutate(excise_tax_rate = all_beverages_excise_tax_rate)

reg_beer <- reg_data %>%
  mutate(excise_tax_rate = beer_excise_tax_rate)

reg_wine <- reg_data %>%
  mutate(excise_tax_rate = wine_excise_tax_rate)

reg_spirits <- reg_data %>%
  mutate(excise_tax_rate = spirits_excise_tax_rate)

m_all <- lm(
  scale_all_beverages ~ PharmImpCount + PermissiveImpCount + FiscalImpCount +
    unemployment + scale_per_capita_income_state + excise_tax_rate +
    factor(State),
  data = reg_all)

m_beer <- lm(
  scale_beer ~ PharmImpCount + PermissiveImpCount + FiscalImpCount +
    unemployment + scale_per_capita_income_state + excise_tax_rate +
    factor(State),
  data = reg_beer)

m_wine <- lm(
  scale_wine ~ PharmImpCount + PermissiveImpCount + FiscalImpCount +
    unemployment + scale_per_capita_income_state + excise_tax_rate +
    factor(State),
  data = reg_wine)

m_spirits <- lm(
  scale_spirits ~ PharmImpCount + PermissiveImpCount + FiscalImpCount +
    unemployment + scale_per_capita_income_state + excise_tax_rate +
    factor(State),
  data = reg_spirits)

vcov_all <- vcovCL(m_all, cluster = ~State)
vcov_beer <- vcovCL(m_beer, cluster = ~State)
vcov_wine <- vcovCL(m_wine, cluster = ~State)
vcov_spirits <- vcovCL(m_spirits, cluster = ~State)

se_all <- sqrt(diag(vcov_all))
se_beer <- sqrt(diag(vcov_beer))
se_wine <- sqrt(diag(vcov_wine))
se_spirits <- sqrt(diag(vcov_spirits))

stargazer(
  m_all, m_beer, m_wine, m_spirits,
  type = "latex",
  out = here("tables","alcohol_impl_fe_all.tex"),
  se = list(se_all, se_beer, se_wine, se_spirits),
  omit = c("factor\\(State\\)", "factor\\(Year\\)", "Constant"),
  title = "Cannabis Policy Implementation and Alcohol Consumption: Controlled Specifications",
  keep.stat = c("n", "rsq", "adj.rsq"),
  column.labels = c("All Beverages", "Beer", "Wine", "Spirits"),
  dep.var.labels = c("", "", "", ""),
  covariate.labels = c(
    "Pharmaceutical implementation count",
    "Permissive implementation count",
    "Fiscal implementation count",
    "Unemployment Rate",
    "Per-Capita Income",
    "Excise Tax Rate"),
  add.lines = list(
    c("State FE", "Yes", "Yes", "Yes", "Yes"),
    c("SE clustered by state", "Yes", "Yes", "Yes", "Yes")),
  digits = 3)


##########################################################

cor_table <- reg_data %>%
  mutate(
    PharmImpCount = round(PharmImpScaleZ * 12 / 100),
    PermissiveImpCount = round(PermissiveImpScaleZ * 12 / 100),
    FiscalImpCount = round(FiscalImpScaleZ * 12 / 100)) %>%
  select(PharmImpCount, PermissiveImpCount, FiscalImpCount) %>%
  cor(use = "complete.obs")
cor_df <- as.data.frame(cor_table) %>%
  rownames_to_column("Variable")

datasummary_df(
  cor_df,
  title = "Correlation Matrix of Implementation Counts",
  fmt = 3,
  output = here("tables", "cor_implementation_counts.tex"))
cor_table
run_ridge <- function(outcome_var, data) {
  fml <- as.formula(
    paste0(
      outcome_var,
      " ~ PharmImpCount + PermissiveImpCount + FiscalImpCount + ",
      "unemployment + scale_per_capita_income_state + factor(State)"))
  
  x <- model.matrix(fml, data = data)[, -1]
  y <- data[[outcome_var]]
  
  penalty_vec <- ifelse(
    colnames(x) %in% c("PharmImpCount", "PermissiveImpCount", "FiscalImpCount"),
    1, 0)
  
  cv.glmnet(
    x = x,
    y = y,
    alpha = 0,
    penalty.factor = penalty_vec,
    standardize = FALSE)}

ridge_all <- run_ridge("scale_all_beverages", reg_data)
ridge_beer <- run_ridge("scale_beer", reg_data)
ridge_wine <- run_ridge("scale_wine", reg_data)
ridge_spirits <- run_ridge("scale_spirits", reg_data)

extract_ridge <- function(model, outcome_name) {
  cf <- as.matrix(coef(model, s = "lambda.min"))
  
  tibble(
    term = rownames(cf),
    estimate = as.numeric(cf[, 1]),
    outcome = outcome_name) %>%
    filter(term %in% c(
      "PharmImpCount",
      "PermissiveImpCount",
      "FiscalImpCount",
      "unemployment",
      "scale_per_capita_income_state"))}

ridge_table <- bind_rows(
  extract_ridge(ridge_all, "All Beverages"),
  extract_ridge(ridge_beer, "Beer"),
  extract_ridge(ridge_wine, "Wine"),
  extract_ridge(ridge_spirits, "Spirits")) %>%
  mutate(
    term = recode(
      term,
      "PharmImpCount" = "Pharmaceutical implementation count",
      "PermissiveImpCount" = "Permissive implementation count",
      "FiscalImpCount" = "Fiscal implementation count",
      "unemployment" = "Unemployment Rate",
      "scale_per_capita_income_state" = "Per-Capita Income")) %>%
  pivot_wider(
    names_from = outcome,
    values_from = estimate) %>%
  rename(Term = term)

ridge_table
datasummary_df(
  ridge_table,
  title = "Ridge Regression Coefficients",
  fmt = 3,
  output = "markdown")
datasummary_df(
  ridge_table,
  title = "Ridge Regression Coefficients",
  fmt = 3,
  output = here("tables", "ridge_table.tex"))


############################################

reg_data <- reg_data %>%
  arrange(State, Year) %>%
  group_by(State) %>%
  mutate(
    scale_per_capita_income_state = as.numeric(scale(per_capita_income)),
    
    L1_PharmImpCount = lag(PharmImpCount, 1),
    L2_PharmImpCount = lag(PharmImpCount, 2),
    L3_PharmImpCount = lag(PharmImpCount, 3),
    
    L1_PermissiveImpCount = lag(PermissiveImpCount, 1),
    L2_PermissiveImpCount = lag(PermissiveImpCount, 2),
    L3_PermissiveImpCount = lag(PermissiveImpCount, 3),
    
    L1_FiscalImpCount = lag(FiscalImpCount, 1),
    L2_FiscalImpCount = lag(FiscalImpCount, 2),
    L3_FiscalImpCount = lag(FiscalImpCount, 3)) %>%
  ungroup()

lag_data <- reg_data %>%
  filter(
    !is.na(scale_all_beverages),
    !is.na(scale_beer),
    !is.na(scale_wine),
    !is.na(scale_spirits),
    !is.na(unemployment),
    !is.na(scale_per_capita_income_state),
    !is.na(L1_PharmImpCount), !is.na(L2_PharmImpCount), !is.na(L3_PharmImpCount),
    !is.na(L1_PermissiveImpCount), !is.na(L2_PermissiveImpCount), !is.na(L3_PermissiveImpCount),
    !is.na(L1_FiscalImpCount), !is.na(L2_FiscalImpCount), !is.na(L3_FiscalImpCount))

lag_all <- lag_data %>%
  mutate(excise_tax_rate = all_beverages_excise_tax_rate)

lag_beer <- lag_data %>%
  mutate(excise_tax_rate = beer_excise_tax_rate)

lag_wine <- lag_data %>%
  mutate(excise_tax_rate = wine_excise_tax_rate)

lag_spirits <- lag_data %>%
  mutate(excise_tax_rate = spirits_excise_tax_rate)

m_all_lag <- lm(
  scale_all_beverages ~
    L1_PharmImpCount + L2_PharmImpCount + L3_PharmImpCount +
    L1_PermissiveImpCount + L2_PermissiveImpCount + L3_PermissiveImpCount +
    L1_FiscalImpCount + L2_FiscalImpCount + L3_FiscalImpCount +
    unemployment + scale_per_capita_income_state + excise_tax_rate +
    factor(State),
  data = lag_all)

m_beer_lag <- lm(
  scale_beer ~
    L1_PharmImpCount + L2_PharmImpCount + L3_PharmImpCount +
    L1_PermissiveImpCount + L2_PermissiveImpCount + L3_PermissiveImpCount +
    L1_FiscalImpCount + L2_FiscalImpCount + L3_FiscalImpCount +
    unemployment + scale_per_capita_income_state + excise_tax_rate +
    factor(State),
  data = lag_beer)

m_wine_lag <- lm(
  scale_wine ~
    L1_PharmImpCount + L2_PharmImpCount + L3_PharmImpCount +
    L1_PermissiveImpCount + L2_PermissiveImpCount + L3_PermissiveImpCount +
    L1_FiscalImpCount + L2_FiscalImpCount + L3_FiscalImpCount +
    unemployment + scale_per_capita_income_state + excise_tax_rate +
    factor(State),
  data = lag_wine)

m_spirits_lag <- lm(
  scale_spirits ~
    L1_PharmImpCount + L2_PharmImpCount + L3_PharmImpCount +
    L1_PermissiveImpCount + L2_PermissiveImpCount + L3_PermissiveImpCount +
    L1_FiscalImpCount + L2_FiscalImpCount + L3_FiscalImpCount +
    unemployment + scale_per_capita_income_state + excise_tax_rate +
    factor(State),
  data = lag_spirits)

vcov_all_lag <- vcovCL(m_all_lag, cluster = ~ State)
vcov_beer_lag <- vcovCL(m_beer_lag, cluster = ~ State)
vcov_wine_lag <- vcovCL(m_wine_lag, cluster = ~ State)
vcov_spirits_lag <- vcovCL(m_spirits_lag, cluster = ~ State)

se_all_lag <- sqrt(diag(vcov_all_lag))
se_beer_lag <- sqrt(diag(vcov_beer_lag))
se_wine_lag <- sqrt(diag(vcov_wine_lag))
se_spirits_lag <- sqrt(diag(vcov_spirits_lag))

stargazer(
  m_all_lag, m_beer_lag, m_wine_lag, m_spirits_lag,
  type = "latex",
  out = here("tables", "alcohol_lagged_models.tex"),
  label = "tab_lags",
  title = "Cannabis Policy Implementation and Alcohol Consumption: Lagged Specifications",
  se = list(se_all_lag, se_beer_lag, se_wine_lag, se_spirits_lag),
  omit = c("factor\\(State\\)", "factor\\(Year\\)", "Constant", "unemployment",
           "scale_per_capita_income_state","excise_tax_rate"),
  keep.stat = c("n", "rsq", "adj.rsq"),
  column.labels = c("All Beverages", "Beer", "Wine", "Spirits"),
  dep.var.labels = c("", "", "", ""),
  covariate.labels = c(
    "Pharmaceutical implementation count$_{t-1}$",
    "\\hspace{1em}Pharmaceutical implementation count$_{t-2}$",
    "\\hspace{1em}Pharmaceutical implementation count$_{t-3}$",
    "Permissive implementation count$_{t-1}$",
    "\\hspace{1em}Permissive implementation count$_{t-2}$",
    "\\hspace{1em}Permissive implementation count$_{t-3}$",
    "Fiscal implementation count$_{t-1}$",
    "\\hspace{1em}Fiscal implementation count$_{t-2}$",
    "\\hspace{1em}Fiscal implementation count$_{t-3}$",
    "Excise Tax Rate"),
  add.lines = list(
    c("State FE", "Yes", "Yes", "Yes", "Yes"),
    c("Controls", "Yes", "Yes", "Yes", "Yes"),
    c("SE clustered by state", "Yes", "Yes", "Yes", "Yes")),
  digits = 3)

tab <- readLines(here("tables", "alcohol_lagged_models.tex"))

perm_idx <- grep("Permissive implementation count\\$_\\{t-1\\}\\$", tab)
fisc_idx <- grep("Fiscal implementation count\\$_\\{t-1\\}\\$", tab)

insert_rule <- "\\\\[-1.8ex] \\hline \\\\[-1.8ex]"

for (i in sort(c(perm_idx, fisc_idx), decreasing = TRUE)) {
  tab <- append(tab, insert_rule, after = i - 1)}

writeLines(tab, here("tables", "alcohol_lagged_models.tex"))
