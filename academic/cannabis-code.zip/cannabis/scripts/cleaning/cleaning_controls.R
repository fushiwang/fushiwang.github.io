library(readxl)
library(dplyr)
library(tidyr)
library(stringr)
library(here)
library(readr)

per_cap_inc <- read_excel(
  here("data", "raw", "dummy","per_cap_inc.xlsx"),
  skip = 4)


per_cap_inc_clean <- per_cap_inc %>%
  rename(
    GeoFIPS = 1,
    GeoName = 2) %>%
  filter(!is.na(GeoFIPS)) %>%
  mutate(
    GeoFIPS = as.character(GeoFIPS),
    GeoFIPS = str_trim(GeoFIPS),
    State = str_trim(GeoName),
    State = str_remove(State, " \\*$")) %>%
  pivot_longer(
    cols = -c(GeoFIPS, GeoName, State),
    names_to = "Year",
    values_to = "per_capita_income") %>%
  mutate(
    Year = as.integer(Year),
    per_capita_income = parse_number(as.character(per_capita_income))) %>%
  filter(!is.na(Year)) %>%
  select(State, Year, per_capita_income, GeoFIPS)


# view result
print(per_cap_inc_clean, n = 20)

# save cleaned file
write_csv(
  per_cap_inc_clean,
  here("data", "cleaned", "per_cap_inc_cleaned.csv"))
