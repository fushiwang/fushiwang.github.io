library(here)
library(tidyverse)
library(readxl)

# state_alcohol_rates_1.xlsx contains a state-by-year panel of alcohol excise
# tax rates (dollars per gallon) for distilled spirits, beer, and wine, as of
# January 1 of each year from 1982 through 2023. Source: Tax Policy Center /
# Federation of Tax Administrators.

fips_lookup <- c(
  "Alabama"=1,"Alaska"=2,"Arizona"=4,"Arkansas"=5,"California"=6,
  "Colorado"=8,"Connecticut"=9,"Delaware"=10,"District of Columbia"=11,
  "Florida"=12,"Georgia"=13,"Hawaii"=15,"Idaho"=16,"Illinois"=17,
  "Indiana"=18,"Iowa"=19,"Kansas"=20,"Kentucky"=21,"Louisiana"=22,
  "Maine"=23,"Maryland"=24,"Massachusetts"=25,"Michigan"=26,
  "Minnesota"=27,"Mississippi"=28,"Missouri"=29,"Montana"=30,
  "Nebraska"=31,"Nevada"=32,"New Hampshire"=33,"New Jersey"=34,
  "New Mexico"=35,"New York"=36,"North Carolina"=37,"North Dakota"=38,
  "Ohio"=39,"Oklahoma"=40,"Oregon"=41,"Pennsylvania"=42,
  "Rhode Island"=44,"South Carolina"=45,"South Dakota"=46,
  "Tennessee"=47,"Texas"=48,"Utah"=49,"Vermont"=50,"Virginia"=51,
  "Washington"=53,"West Virginia"=54,"Wisconsin"=55,"Wyoming"=56)

# Helpers: "n.a." -> NA; strip trailing "*"; coerce to numeric.
parse_rate <- function(x) {
  x <- str_trim(x)
  x[x == "n.a."] <- NA
  x <- str_remove(x, "\\s*\\*\\s*$")
  as.numeric(x)}

has_local_tax <- function(x) {
  str_detect(replace_na(x, ""), "\\*\\s*$")}

raw <- read_excel(
  here("data", "raw", "dummy", "state_alcohol_rates_1.xlsx"),
  sheet = "1982-2023",
  col_names = c("State", "State_Ab", "Year",
                "spirits_raw", "beer_raw", "wine_raw"),
  range     = cell_cols("A:F"),
  skip      = 4,
  col_types = "text")

cleaned <- raw %>%
  mutate(State = if_else(State == "District Of Columbia",
                         "District of Columbia", State)) %>%
  filter(State %in% names(fips_lookup)) %>%
  mutate(
    Year = as.integer(Year),
    FIPS = unname(fips_lookup[State])) %>%
  filter(!is.na(Year), Year >= 1994, Year <= 2023) %>%
  mutate(
    spirits_excise_tax_rate = parse_rate(spirits_raw),
    beer_excise_tax_rate    = parse_rate(beer_raw),
    wine_excise_tax_rate    = parse_rate(wine_raw),
    spirits_control_state   = is.na(spirits_excise_tax_rate),
    wine_control_state      = is.na(wine_excise_tax_rate),
    spirits_includes_local_tax = has_local_tax(spirits_raw),
    beer_includes_local_tax    = has_local_tax(beer_raw),
    wine_includes_local_tax    = has_local_tax(wine_raw),
    across(ends_with("_excise_tax_rate"), ~ round(.x, 4))) %>%
  select(
    State, State_Ab, FIPS, Year,
    spirits_excise_tax_rate, beer_excise_tax_rate, wine_excise_tax_rate,
    spirits_control_state, wine_control_state,
    spirits_includes_local_tax, beer_includes_local_tax, wine_includes_local_tax) %>%
  arrange(State, Year)

write_csv(
  cleaned,
  here("data", "cleaned", "state_alcohol_rates_cleaned.csv"))
