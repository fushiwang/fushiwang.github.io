library(here)
library(haven)
library(tidyverse)

raw <- read_dta(here("data","raw","dataverse_files", "MML RCL Policies 12225.dta"))
full <- readxl::read_xlsx(here("data","raw","dataverse_files","Cannabis Policies Full Dataset 81425.xlsx"))
condensed <- readxl::read_xlsx(here("data","raw","dataverse_files","Cannabis Policies Condensed Data 81425.xlsx"))


