
### RUN THIS BLOCK ###
library(here)

scripts <- c(
  "cleaning_alcohol_rates.R",
  "cleaning_alcohol_sales.R",
  "cleaning_alcohol.R",
  "cleaning_controls.R",
  "cleaning_full_laws.R",
  "cleaning_laws.R",
  "cleaning_unemployment.R"
)

for (s in scripts) {
  cat("Running", s, "...\n")
  source(here("scripts", "cleaning", s))
}

cat("All cleaning completed, and cleaned data saved! yay no errors.\n")
### RUN THIS BLOCK ###