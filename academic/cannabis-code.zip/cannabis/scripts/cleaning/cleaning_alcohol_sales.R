library(here)
library(tidyverse)

# Parse the fixed-width NIAAA per-capita file (pcyr1970-2023.txt).
# Column positions come from the record layout in the file header.
col_positions <- fwf_positions(
  start = c(1,  6,  9, 22, 52, 63, 72),
  end   = c(4,  7,  9, 30, 60, 67, 72),
  col_names = c(
    "year", "fips", "beverage_type",
    "gallons_ethanol",
    "population_21plus",
    "ethanol_per_capita_21plus",
    "data_source_type"))

# FIPS -> state name lookup (50 states + DC).
fips_labels <- c(
  "1"="Alabama","2"="Alaska","4"="Arizona","5"="Arkansas","6"="California",
  "8"="Colorado","9"="Connecticut","10"="Delaware","11"="District of Columbia",
  "12"="Florida","13"="Georgia","15"="Hawaii","16"="Idaho","17"="Illinois",
  "18"="Indiana","19"="Iowa","20"="Kansas","21"="Kentucky","22"="Louisiana",
  "23"="Maine","24"="Maryland","25"="Massachusetts","26"="Michigan",
  "27"="Minnesota","28"="Mississippi","29"="Missouri","30"="Montana",
  "31"="Nebraska","32"="Nevada","33"="New Hampshire","34"="New Jersey",
  "35"="New Mexico","36"="New York","37"="North Carolina","38"="North Dakota",
  "39"="Ohio","40"="Oklahoma","41"="Oregon","42"="Pennsylvania",
  "44"="Rhode Island","45"="South Carolina","46"="South Dakota",
  "47"="Tennessee","48"="Texas","49"="Utah","50"="Vermont","51"="Virginia",
  "53"="Washington","54"="West Virginia","55"="Wisconsin","56"="Wyoming")

raw <- read_fwf(
  here("data", "raw", "alcohol", "pcyr1970-2023.txt"),
  col_positions = col_positions,
  col_types = cols(.default = col_character()),
  skip = 130,
  na = c(".", "", "NA")) %>%
  mutate(
    year                      = as.integer(year),
    fips                      = as.integer(fips),
    beverage_type             = as.integer(beverage_type),
    data_source_type          = as.integer(data_source_type),
    gallons_ethanol           = as.numeric(gallons_ethanol),
    population_21plus         = as.numeric(population_21plus),
    ethanol_per_capita_21plus = as.numeric(ethanol_per_capita_21plus) / 10000) %>%
  filter(fips <= 56)

# The data_source_type flag is only populated on per-beverage rows, never on the "All beverages" aggregate. Inherit each state-year's reporting method from the beer row (fall back to spirits, then wine).
source_by_state_year <- raw %>%
  filter(beverage_type %in% c(1, 2, 3), !is.na(data_source_type)) %>%
  mutate(priority = case_when(beverage_type == 3 ~ 1,
                              beverage_type == 1 ~ 2,
                              beverage_type == 2 ~ 3)) %>%
  arrange(year, fips, priority) %>%
  distinct(year, fips, .keep_all = TRUE) %>%
  select(year, fips, data_source_type)

all_bev <- raw %>%
  filter(beverage_type == 4) %>%
  select(-data_source_type) %>%
  left_join(source_by_state_year, by = c("year", "fips")) %>%
  mutate(state = fips_labels[as.character(fips)])

# Per-beverage gallons-of-ethanol sold, pivoted wide: one column each for spirits, wine, and beer.
by_beverage <- raw %>%
  filter(beverage_type %in% c(1, 2, 3)) %>%
  mutate(beverage = recode(beverage_type,
                           `1` = "spirits",
                           `2` = "wine",
                           `3` = "beer")) %>%
  select(year, fips, beverage, gallons_ethanol) %>%
  pivot_wider(
    names_from = beverage,
    values_from = gallons_ethanol,
    names_glue = "sales_{beverage}_gallons_ethanol")

# Sales volume: annual consumption for every state, 1994-2023, with per-beverage gallons-of-ethanol columns alongside the all-beverage total.
annual_sales_volume <- all_bev %>%
  filter(year >= 1994, year <= 2023) %>%
  left_join(by_beverage, by = c("year", "fips")) %>%
  transmute(
    year,
    state,
    sales_all_beverages_gallons_ethanol = gallons_ethanol,
    sales_spirits_gallons_ethanol,
    sales_wine_gallons_ethanol,
    sales_beer_gallons_ethanol,
    population_21plus,
    ethanol_per_capita_21plus) %>%
  arrange(year, state)

# Sales tax: only state-years that reported via tax methodology.
# data_source_type 2 = State monthly sales tax data
# data_source_type 4 = State annual sales tax data
# The methodology flag is only recorded from 2001 onward in the source file.
annual_sales_tax <- all_bev %>%
  filter(year >= 2001, year <= 2023,
         data_source_type %in% c(2, 4)) %>%
  transmute(
    year,
    state,
    sales_all_beverages_gallons_ethanol = gallons_ethanol,
    population_21plus,
    ethanol_per_capita_21plus) %>%
  arrange(year, state)

write_csv(
  annual_sales_volume,
  here("data", "cleaned", "alcohol_annual_sales_volume_1994_2023.csv"))
write_csv(
  annual_sales_tax,
  here("data", "cleaned", "alcohol_annual_sales_tax_2001_2023.csv"))
