library(here)
library(tidyverse)
library(readxl)

# FIPS -> state name (50 states + DC + Puerto Rico, all present in this file).
fips_labels <- c(
  "1"="Alabama","2"="Alaska","4"="Arizona","5"="Arkansas","6"="California",
  "8"="Colorado","9"="Connecticut","10"="Delaware","11"="District of Columbia",
  "12"="Florida","13"="Georgia","15"="Hawaii","16"="Idaho","17"="Illinois",
  "18"="Indiana","19"="Iowa","20"="Kansas","21"="Kentucky","22"="Louisiana",
  "23"="Maine","24"="Maryland","25"="Massachusetts","26"="Michigan",
  "27"="Minnesota","28"="Mississippi","29"="Missouri","30"="Montana",
  "31"="Nebraska","32"="Nevada","33"="New Hampshire","34"="New Jersey",
  "35"="New Mexico","36"="New York","37"="North Carolina","38"="North Dakota",
  "39"="Ohio","40"="Oklahoma","41"="Oregon","42"="Pennsylvania",
  "44"="Rhode Island","45"="South Carolina","46"="South Dakota",
  "47"="Tennessee","48"="Texas","49"="Utah","50"="Vermont","51"="Virginia",
  "53"="Washington","54"="West Virginia","55"="Wisconsin","56"="Wyoming",
  "72"="Puerto Rico")

# Layout of the raw sheet:
#   row 1-2 : title / year range
#   row 3   : blank
#   row 4   : column headers  -- col 1 = "Series ID", cols 2..361 = "Mon\nYYYY"
#   rows 5+ : one row per state, with the monthly unemployment rate
raw <- read_excel(
  here("data", "raw", "dummy", "unemployment.xlsx"),
  col_names = FALSE,
  skip = 3)

header <- as.character(raw[1, ])
values <- raw[-1, ]
colnames(values) <- header
colnames(values)[1] <- "series_id"

monthly <- values %>%
  mutate(
    fips  = as.integer(substr(series_id, 6, 7)),
    state = fips_labels[as.character(fips)]) %>%
  select(-series_id, -fips) %>%
  pivot_longer(
    cols = -state,
    names_to = "month_label",
    values_to = "unemployment_rate") %>%
  mutate(
    unemployment_rate = as.numeric(unemployment_rate),
    year = as.integer(str_extract(month_label, "\\d{4}")))

annual <- monthly %>%
  group_by(year, state) %>%
  summarise(unemployment_rate = mean(unemployment_rate, na.rm = TRUE),
            .groups = "drop") %>%
  mutate(state = factor(state, levels = unname(fips_labels))) %>%
  arrange(year, state) %>%
  pivot_wider(names_from = state, values_from = unemployment_rate) %>%
  arrange(year)

write_csv(
  annual,
  here("data", "cleaned", "unemployment_cleaned.csv"))
