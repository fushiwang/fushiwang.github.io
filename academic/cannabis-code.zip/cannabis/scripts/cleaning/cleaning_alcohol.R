library(here)
library(tidyverse)

raw <- read_csv(here("data","raw","alcohol","niaaa_table4_apparent_per_capita_alcohol_consumption_1977_2023.csv"))

write_csv(raw, here("data","cleaned","alcohol_consumption_cleaned.csv"))

