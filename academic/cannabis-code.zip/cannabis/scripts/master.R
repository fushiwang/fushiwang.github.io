library(here)

cat("Starting full pipeline...\n")

# 1. Cleaning
cat("\n=== Running cleaning ===\n")
source(here("scripts", "cleaning", "master_cleaning.R"))

# 2. Explore
cat("\n=== Running explore ===\n")
source(here("scripts", "explore", "master_explore.R"))

# 3. Model
cat("\n=== Running model ===\n")
source(here("scripts", "model", "modeling.R"))

cat("\nAll scripts completed.\n")
