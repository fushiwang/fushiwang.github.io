Does Cannabis Policy Displace Alcohol? Evidence from U.S. State-Level Consumption Data, 1994–2023
Fushi Wang and Ajay Raman

This archive contains the authors' R scripts and cleaned inputs. The analysis combines RAND OPTIC cannabis policy measures, NIAAA apparent alcohol consumption, economic controls, and alcohol excise taxes.

Extract the archive and open the R project. With the project folder as the working directory, run:
  Rscript scripts/model/modeling.R
  Rscript scripts/explore/master_explore.R

Tables and figures are written to tables/ and figures/. To rebuild from the original raw data, use scripts/master.R after supplying the original raw inputs under data/raw/ at the paths in scripts/cleaning/. The included cleaned inputs support the model and exploration scripts directly.

R packages loaded by the project scripts:
  dplyr, fixest, glmnet, gridExtra, haven, here, lmtest, modelsummary, readr, readxl, sandwich, stargazer, stringr, tidyr, tidyverse
